# Clipkaar

CapCut-style video editor for Android: saved projects, one + button for videos, photos, music, free built-in tunes and sound effects, Magic one-tap (16:9 + blur background + clean voice + AI captions), transitions, stickers and emoji, drag to reorder clips, multi-clip timeline, split, speed, crop (ratio, rotate, mirror), 13 filters with intensity, adjust, AI auto captions (Whisper base.en, English, word-by-word timing, offline) with 32 caption styles, AI voice isolation (RNNoise), text styles, blur boxes, fast hardware MP4 export.

The build downloads the AI libraries and the speech model automatically (`prepare.sh`), so the APK is about 100 MB.

## Get the APK
Every push builds the app automatically (GitHub → **Actions**).
When the run turns green, open **Releases** on the repo page and download **Clipkaar.apk** on your phone.

## Install on phone
Open the downloaded `Clipkaar.apk`. If Android asks, allow "Install unknown apps" for your browser / Files app, then tap **Install**.

Exported videos are saved in **Movies/Clipkaar** (Gallery). Captions (.srt) go to **Downloads/Clipkaar**.

## Edit the app
The whole editor is one file: `app/src/main/assets/index.html`. Change it, push, and a new APK is built.
