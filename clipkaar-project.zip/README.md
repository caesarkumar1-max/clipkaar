# Clipkaar

CapCut-style video editor for Android: multi-clip timeline, split, speed, crop (ratio, rotate, mirror), 13 filters with intensity, adjust, auto caption timing, text styles, blur boxes, voice isolation, export to MP4.

## Get the APK
Every push builds the app automatically (GitHub → **Actions**).
When the run turns green, open **Releases** on the repo page and download **Clipkaar.apk** on your phone.

## Install on phone
Open the downloaded `Clipkaar.apk`. If Android asks, allow "Install unknown apps" for your browser / Files app, then tap **Install**.

Exported videos are saved in **Movies/Clipkaar** (Gallery). Captions (.srt) go to **Downloads/Clipkaar**.

## Edit the app
The whole editor is one file: `app/src/main/assets/index.html`. Change it, push, and a new APK is built.
