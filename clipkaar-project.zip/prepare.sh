#!/usr/bin/env bash
# Downloads the AI libraries and the Whisper speech model into the app's assets.
# Gradle runs this automatically before every build (see app/build.gradle).
set -e
A=app/src/main/assets
mkdir -p "$A/lib" "$A/models/onnx-community/whisper-base.en_timestamped/onnx"

if [ ! -f "$A/lib/transformers.min.js" ]; then
  T=$(mktemp -d)
  (cd "$T" && npm init -y >/dev/null && npm install --no-audit --no-fund --ignore-scripts \
      @huggingface/transformers@3.7.6 @shiguredo/rnnoise-wasm@2025.1.5 mp4-muxer@5.2.2)
  N="$T/node_modules"
  cp "$N/@huggingface/transformers/dist/transformers.min.js" "$A/lib/"
  cp "$N/@huggingface/transformers/dist/ort-wasm-simd-threaded.jsep.mjs" "$A/lib/"
  cp "$N/@huggingface/transformers/dist/ort-wasm-simd-threaded.jsep.wasm" "$A/lib/"
  cp "$N/@shiguredo/rnnoise-wasm/dist/rnnoise.js" "$A/lib/"
  cp "$N/mp4-muxer/build/mp4-muxer.js" "$A/lib/"
  rm -rf "$T"
fi

rm -rf "$A/models/Xenova"
M="$A/models/onnx-community/whisper-base.en_timestamped"
B="https://huggingface.co/onnx-community/whisper-base.en_timestamped/resolve/main"
get() { [ -s "$M/$1" ] || curl -fsSL --retry 4 --retry-delay 3 -o "$M/$1" "$B/$1" || { echo "warning: could not download $1"; rm -f "$M/$1"; }; }
for f in config.json generation_config.json preprocessor_config.json tokenizer.json tokenizer_config.json \
         special_tokens_map.json added_tokens.json vocab.json merges.txt normalizer.json; do get "$f"; done
get onnx/encoder_model_quantized.onnx
get onnx/decoder_model_merged_quantized.onnx

echo "Assets ready:"; du -sh "$A/lib" "$A/models"
