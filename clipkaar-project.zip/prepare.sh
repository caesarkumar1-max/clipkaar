#!/usr/bin/env bash
# Downloads the AI libraries and the Whisper speech model into the app's assets.
# Gradle runs this automatically before every build (see app/build.gradle).
set -e
A=app/src/main/assets
mkdir -p "$A/lib"

if [ ! -f "$A/lib/transformers.min.js" ]; then
  T=$(mktemp -d)
  (cd "$T" && npm init -y >/dev/null && npm install --no-audit --no-fund --ignore-scripts \
      @huggingface/transformers@3.7.6 @shiguredo/rnnoise-wasm@2025.1.5 mp4-muxer@5.2.2 @mediapipe/tasks-vision@0.10.21)
  N="$T/node_modules"
  cp "$N/@huggingface/transformers/dist/transformers.min.js" "$A/lib/"
  cp "$N/@huggingface/transformers/dist/ort-wasm-simd-threaded.jsep.mjs" "$A/lib/"
  cp "$N/@huggingface/transformers/dist/ort-wasm-simd-threaded.jsep.wasm" "$A/lib/"
  cp "$N/@shiguredo/rnnoise-wasm/dist/rnnoise.js" "$A/lib/"
  cp "$N/mp4-muxer/build/mp4-muxer.js" "$A/lib/"
  mkdir -p "$A/lib/mediapipe/wasm"
  cp "$N/@mediapipe/tasks-vision/vision_bundle.mjs" "$A/lib/mediapipe/"
  cp "$N/@mediapipe/tasks-vision/wasm/"* "$A/lib/mediapipe/wasm/"
  rm -rf "$T"
fi

# face detector for Auto reframe
[ -s "$A/lib/mediapipe/blaze_face_short_range.tflite" ] || curl -fsSL --retry 4 -o "$A/lib/mediapipe/blaze_face_short_range.tflite" \
  "https://storage.googleapis.com/mediapipe-models/face_detector/blaze_face_short_range/float16/1/blaze_face_short_range.tflite" || echo "warning: face model not downloaded (Auto reframe will use the backup finder)"
rm -rf "$A/models/Xenova"
getmodel() {
  M="$A/models/onnx-community/$1"; B="https://huggingface.co/onnx-community/$1/resolve/main"; mkdir -p "$M/onnx"
  get() { [ -s "$M/$1" ] || curl -fsSL --retry 4 --retry-delay 3 -o "$M/$1" "$B/$1" || { echo "warning: could not download $1"; rm -f "$M/$1"; }; }
  for f in config.json generation_config.json preprocessor_config.json tokenizer.json tokenizer_config.json \
           special_tokens_map.json added_tokens.json vocab.json merges.txt normalizer.json; do get "$f"; done
  get onnx/encoder_model_quantized.onnx
  get onnx/decoder_model_merged_quantized.onnx
}
getmodel whisper-tiny.en_timestamped   # backup captions if the phone AI can't run
rm -rf "$A/models/onnx-community/whisper-base.en_timestamped"

# On-phone speech AI (much faster): whisper.cpp source + English models
W=app/src/main/cpp/whisper.cpp
if [ ! -f "$W/CMakeLists.txt" ]; then
  rm -rf "$W"; git clone -q --depth 1 --branch v1.9.5 https://github.com/ggml-org/whisper.cpp "$W"
fi
mkdir -p "$A/whisper"
gw() { [ -s "$A/whisper/$2" ] || curl -fsSL --retry 4 --retry-delay 3 -o "$A/whisper/$2" "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/$1" || { echo "warning: could not download $1"; rm -f "$A/whisper/$2"; }; }
gw ggml-tiny.en-q8_0.bin ggml-tiny.en.bin    # Fast
gw ggml-base.en-q5_1.bin ggml-base.en.bin    # Accurate

echo "Assets ready:"; du -sh "$A/lib" "$A/models" "$A/whisper"
