package com.clipkaar.app;

import android.content.Context;
import android.content.res.AssetFileDescriptor;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/** On-phone English speech-to-text (whisper.cpp), using all the phone's fast CPU cores. Free and offline. */
public class Asr {
    private static boolean libOk;
    static {
        try { System.loadLibrary("clipkaar_asr"); libOk = true; }
        catch (Throwable t) { libOk = false; }
    }

    private static native long nInit(String path, int kind);
    private static native byte[] nRun(long ctx, float[] pcm, int threads);
    private static native void nFree(long ctx);
    private static native void nAbort(boolean on);

    private final Context ctx;
    private long handle;
    private String handleKind;

    public Asr(Context ctx) { this.ctx = ctx.getApplicationContext(); }

    private static String asset(String kind) { return "whisper/" + ("accurate".equals(kind) ? "ggml-base.en.bin" : "ggml-tiny.en.bin"); }

    public boolean available(String kind) {
        if (!libOk) return false;
        try (AssetFileDescriptor fd = ctx.getAssets().openFd(asset(kind))) { return fd.getLength() > 1000000; }
        catch (Exception e) { return false; }
    }

    public static int threads() {
        int n = Runtime.getRuntime().availableProcessors();
        return Math.max(1, Math.min(4, n >= 6 ? 4 : n - 1));   // big cores only; more threads is slower on phones
    }

    /** Copies the model out of the APK once, so the AI can map it from a normal file. */
    private File modelFile(String kind) throws Exception {
        String a = asset(kind);
        long len;
        try (AssetFileDescriptor fd = ctx.getAssets().openFd(a)) { len = fd.getLength(); }
        File f = new File(ctx.getFilesDir(), a.replace('/', '_'));
        if (f.exists() && f.length() == len) return f;
        File tmp = new File(f.getPath() + ".part");
        try (InputStream in = ctx.getAssets().open(a); OutputStream out = new FileOutputStream(tmp)) {
            byte[] b = new byte[1 << 20]; int n;
            while ((n = in.read(b)) > 0) out.write(b, 0, n);
        }
        if (!tmp.renameTo(f)) throw new Exception("could not save speech model");
        return f;
    }

    private long get(String kind) throws Exception {
        if (handle != 0 && kind.equals(handleKind)) return handle;
        if (handle != 0) { nFree(handle); handle = 0; handleKind = null; }   // only one model in memory
        long h = nInit(modelFile(kind).getAbsolutePath(), "accurate".equals(kind) ? 1 : 0);
        if (h == 0) throw new Exception("speech model could not load");
        handle = h; handleKind = kind;
        return h;
    }

    /** pcm = 16 kHz mono. Returns JSON {"chunks":[{"text":" word","timestamp":[s,e]}]}. */
    public synchronized String run(String kind, float[] pcm) throws Exception {
        if (!libOk) throw new Exception("speech AI not available on this phone");
        long h = get(kind);
        byte[] r = nRun(h, pcm, threads());
        if (r == null) throw new Exception("speech AI stopped");
        return new String(r, StandardCharsets.UTF_8);
    }

    /** Stops the piece being worked on right now (used when captions are cancelled). */
    public void cancel() { if (libOk) nAbort(true); }

    public synchronized void release() { if (handle != 0) { nFree(handle); handle = 0; handleKind = null; } }
}
