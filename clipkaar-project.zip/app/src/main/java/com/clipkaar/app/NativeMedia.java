package com.clipkaar.app;

import android.content.Context;
import android.media.AudioFormat;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;

import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.transformer.Composition;
import androidx.media3.transformer.ExportException;
import androidx.media3.transformer.ExportResult;
import androidx.media3.transformer.ProgressHolder;
import androidx.media3.transformer.Transformer;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/** Fast work done with the phone's own media chips: reading a video's sound, and converting videos the editor can't play. */
public class NativeMedia {
    public interface Report { void send(String id, String type, String a, String b); }

    private final Context ctx;
    private final Report report;
    private Transformer transformer;
    private String convId;

    public NativeMedia(Context ctx, Report report) { this.ctx = ctx; this.report = report; }

    /** Decode the audio track to 48 kHz mono float samples in a cache file. */
    public void decodeAudio(String uriStr, String id) {
        new Thread(() -> {
            MediaExtractor ex = new MediaExtractor();
            MediaCodec dec = null;
            File outFile = new File(ctx.getCacheDir(), "aud_" + id + ".f32");
            try {
                ex.setDataSource(ctx, Uri.parse(uriStr), null);
                int track = -1; MediaFormat fmt = null;
                for (int i = 0; i < ex.getTrackCount(); i++) {
                    MediaFormat f = ex.getTrackFormat(i); String m = f.getString(MediaFormat.KEY_MIME);
                    if (m != null && m.startsWith("audio/")) { track = i; fmt = f; break; }
                }
                if (track < 0) { report.send(id, "none", "", ""); return; }
                ex.selectTrack(track);
                long durUs = fmt.containsKey(MediaFormat.KEY_DURATION) ? fmt.getLong(MediaFormat.KEY_DURATION) : 0;
                dec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME));
                dec.configure(fmt, null, null, 0); dec.start();
                int srcRate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE), chans = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
                boolean isFloat = false;
                BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(outFile), 1 << 20);
                MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
                boolean inDone = false, outDone = false;
                double ratio = srcRate / 48000.0;
                long srcIndex = 0;      // index of the first sample of the current chunk
                long outCount = 0;      // samples written at 48 kHz
                float prev = 0f;        // last sample of the previous chunk
                int lastPct = -1;
                ByteBuffer ob = ByteBuffer.allocate(4 * 8192).order(ByteOrder.LITTLE_ENDIAN);
                while (!outDone) {
                    if (!inDone) {
                        int ii = dec.dequeueInputBuffer(10000);
                        if (ii >= 0) {
                            ByteBuffer ib = dec.getInputBuffer(ii);
                            int n = ex.readSampleData(ib, 0);
                            if (n < 0) { dec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inDone = true; }
                            else {
                                long t = ex.getSampleTime();
                                dec.queueInputBuffer(ii, 0, n, t, 0); ex.advance();
                                if (durUs > 0) { int pct = (int) (t * 100 / durUs); if (pct != lastPct) { lastPct = pct; report.send(id, "prog", String.valueOf(Math.min(99, pct) / 100.0), ""); } }
                            }
                        }
                    }
                    int oi = dec.dequeueOutputBuffer(info, 10000);
                    if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        MediaFormat of = dec.getOutputFormat();
                        if (of.containsKey(MediaFormat.KEY_PCM_ENCODING)) isFloat = of.getInteger(MediaFormat.KEY_PCM_ENCODING) == AudioFormat.ENCODING_PCM_FLOAT;
                        if (of.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) chans = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
                        if (of.containsKey(MediaFormat.KEY_SAMPLE_RATE)) { srcRate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE); ratio = srcRate / 48000.0; }
                    } else if (oi >= 0) {
                        ByteBuffer buf = dec.getOutputBuffer(oi);
                        if (buf != null && info.size > 0) {
                            buf.position(info.offset); buf.limit(info.offset + info.size); buf.order(ByteOrder.LITTLE_ENDIAN);
                            int frames = info.size / ((isFloat ? 4 : 2) * Math.max(1, chans));
                            float[] mono = new float[frames];
                            for (int f = 0; f < frames; f++) {
                                float s = 0;
                                for (int c = 0; c < chans; c++) s += isFloat ? buf.getFloat() : buf.getShort() / 32768f;
                                mono[f] = s / chans;
                            }
                            // linear resample to 48 kHz
                            while (true) {
                                double p = outCount * ratio - srcIndex; // position inside this chunk
                                if (p >= frames - 1) break;
                                int i0 = (int) Math.floor(p); double fr = p - i0;
                                float a = i0 < 0 ? prev : mono[i0], b = mono[Math.max(0, i0 + 1)];
                                float v = (float) (a + (b - a) * fr);
                                ob.putFloat(v);
                                if (ob.remaining() < 4) { bos.write(ob.array(), 0, ob.position()); ob.clear(); }
                                outCount++;
                            }
                            if (frames > 0) prev = mono[frames - 1];
                            srcIndex += frames;
                        }
                        dec.releaseOutputBuffer(oi, false);
                        if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outDone = true;
                    }
                }
                bos.write(ob.array(), 0, ob.position()); bos.close();
                report.send(id, "done", outFile.getName(), String.valueOf(outCount));
            } catch (Exception e) {
                outFile.delete();
                report.send(id, "err", String.valueOf(e.getMessage()), "");
            } finally {
                try { if (dec != null) { dec.stop(); dec.release(); } } catch (Exception ignored) { }
                ex.release();
            }
        }).start();
    }

    /** Re-encode a video to H.264 + AAC so the editor can play it (TikTok HD / HEVC videos). Must run on the main thread. */
    public void convert(String uriStr, String id) {
        new Handler(Looper.getMainLooper()).post(() -> {
            try {
                File out = new File(ctx.getCacheDir(), "conv_" + id + ".mp4");
                final Transformer[] holder = new Transformer[1];
                Transformer t = new Transformer.Builder(ctx)
                        .setVideoMimeType(MimeTypes.VIDEO_H264)
                        .setAudioMimeType(MimeTypes.AUDIO_AAC)
                        .addListener(new Transformer.Listener() {
                            @Override public void onCompleted(Composition composition, ExportResult result) {
                                if (transformer == holder[0]) transformer = null;
                                report.send(id, "done", out.getName(), String.valueOf(out.length()));
                            }
                            @Override public void onError(Composition composition, ExportResult result, ExportException e) {
                                if (transformer == holder[0]) transformer = null;
                                out.delete();
                                report.send(id, "err", e.getMessage() + " (" + e.getErrorCodeName() + ")", "");
                            }
                        })
                        .build();
                holder[0] = t; transformer = t; convId = id;
                t.start(MediaItem.fromUri(Uri.parse(uriStr)), out.getAbsolutePath());
                Handler h = new Handler(Looper.getMainLooper());
                ProgressHolder ph = new ProgressHolder();
                h.postDelayed(new Runnable() {
                    @Override public void run() {
                        if (transformer != t) return;
                        if (t.getProgress(ph) == Transformer.PROGRESS_STATE_AVAILABLE) report.send(id, "prog", String.valueOf(ph.progress / 100.0), "");
                        h.postDelayed(this, 500);
                    }
                }, 500);
            } catch (Exception e) {
                report.send(id, "err", String.valueOf(e.getMessage()), "");
            }
        });
    }

    public void cancelConvert() {
        new Handler(Looper.getMainLooper()).post(() -> {
            if (transformer != null) { transformer.cancel(); transformer = null; if (convId != null) report.send(convId, "err", "cancelled", ""); }
        });
    }

    public boolean deleteCache(String name) {
        if (name == null || name.contains("/") || name.contains("..")) return false;
        return new File(ctx.getCacheDir(), name).delete();
    }

    public long cacheSize(String name) {
        if (name == null || name.contains("/") || name.contains("..")) return -1;
        File f = new File(ctx.getCacheDir(), name); return f.exists() ? f.length() : -1;
    }
}
