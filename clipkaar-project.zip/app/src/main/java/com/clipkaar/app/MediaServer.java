package com.clipkaar.app;

import android.content.ContentResolver;
import android.content.res.AssetFileDescriptor;
import android.net.Uri;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URLDecoder;
import java.security.SecureRandom;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * A tiny HTTP server on 127.0.0.1 that streams files from the phone's gallery to the editor.
 * The video player handles normal HTTP with byte ranges well, so videos open instantly and seek fast,
 * and nothing is copied. A random token in every link keeps other apps out.
 */
public class MediaServer extends Thread {
    private final ContentResolver cr;
    private final java.io.File cacheDir;
    private final ServerSocket ss;
    public final String token;

    /** Speech-to-text hook: the editor POSTs 16 kHz float audio to /asr and gets the words back. */
    public interface AsrHandler { String run(String kind, float[] pcm) throws Exception; }
    public volatile AsrHandler asr;

    public MediaServer(ContentResolver cr, java.io.File cacheDir) throws Exception {
        this.cr = cr; this.cacheDir = cacheDir;
        this.ss = new ServerSocket(0, 50, InetAddress.getByName("127.0.0.1"));
        byte[] b = new byte[16]; new SecureRandom().nextBytes(b);
        StringBuilder sb = new StringBuilder(); for (byte x : b) sb.append(String.format("%02x", x));
        this.token = sb.toString();
        setDaemon(true);
    }

    public String base() { return "http://127.0.0.1:" + ss.getLocalPort() + "/m/" + token; }

    @Override
    public void run() {
        while (!isInterrupted()) {
            try {
                Socket s = ss.accept();
                Thread t = new Thread(() -> handle(s)); t.setDaemon(true); t.start();
            } catch (Exception e) { if (ss.isClosed()) return; }
        }
    }

    private void handle(Socket s) {
        try (Socket sock = s) {
            sock.setSoTimeout(30000);
            InputStream in = new BufferedInputStream(sock.getInputStream());
            String line = readLine(in); if (line == null) return;
            String[] parts = line.split(" ");
            if (parts.length < 2) return;
            String method = parts[0], target = parts[1];
            Map<String, String> h = new HashMap<>();
            String l; while ((l = readLine(in)) != null && !l.isEmpty()) { int i = l.indexOf(':'); if (i > 0) h.put(l.substring(0, i).trim().toLowerCase(Locale.ROOT), l.substring(i + 1).trim()); }
            OutputStream out = sock.getOutputStream();
            String cors = "Access-Control-Allow-Origin: *\r\nAccess-Control-Allow-Headers: Range, Content-Type\r\nAccess-Control-Allow-Methods: GET, HEAD, POST, OPTIONS\r\n"
                    + "Access-Control-Allow-Private-Network: true\r\nAccess-Control-Max-Age: 86400\r\n"
                    + "Access-Control-Expose-Headers: Content-Range, Content-Length, Accept-Ranges\r\nCross-Origin-Resource-Policy: cross-origin\r\n";
            if ("OPTIONS".equals(method)) { out.write(("HTTP/1.1 204 No Content\r\n" + cors + "Content-Length: 0\r\nConnection: close\r\n\r\n").getBytes()); out.flush(); return; }
            String prefix = "/m/" + token;
            if (!(target.startsWith(prefix + "?") || target.startsWith(prefix + "/"))) { out.write(("HTTP/1.1 403 Forbidden\r\nContent-Length: 0\r\nConnection: close\r\n\r\n").getBytes()); return; }
            if (target.startsWith(prefix + "/asr")) { handleAsr(method, target, h, in, out, cors); return; }
            // two kinds of links: ?u=<content uri> for gallery files, /f?n=<name> for files the app made (converted video, decoded audio)
            AssetFileDescriptor afd = null; FileInputStream fin0; long total0; String type0;
            int fq = target.indexOf("/f?n=");
            if (target.startsWith(prefix + "/f?n=") && fq >= 0) {
                String name = URLDecoder.decode(target.substring(fq + 5).split("&")[0], "UTF-8");
                if (name.contains("/") || name.contains("..") || name.isEmpty()) throw new Exception("name");
                java.io.File f = new java.io.File(cacheDir, name);
                fin0 = new FileInputStream(f); total0 = f.length();
                type0 = name.endsWith(".mp4") ? "video/mp4" : "application/octet-stream";
            } else {
                int q = target.indexOf("?u=");
                if (q < 0) { out.write(("HTTP/1.1 400 Bad Request\r\nContent-Length: 0\r\nConnection: close\r\n\r\n").getBytes()); return; }
                Uri uri = Uri.parse(URLDecoder.decode(target.substring(q + 3).split("&")[0], "UTF-8"));
                afd = cr.openAssetFileDescriptor(uri, "r");
                if (afd == null) throw new Exception("open");
                fin0 = afd.createInputStream(); total0 = afd.getLength();
                type0 = cr.getType(uri);
            }
            try (FileInputStream fin = fin0) {
                long total = total0; if (total < 0) total = fin.getChannel().size() - fin.getChannel().position();
                long start = 0, end = total - 1; boolean partial = false;
                String range = h.get("range");
                if (range != null && range.startsWith("bytes=")) {
                    String[] p = range.substring(6).split(",")[0].split("-", -1);
                    if (!p[0].trim().isEmpty()) { start = Long.parseLong(p[0].trim()); if (p.length > 1 && !p[1].trim().isEmpty()) end = Math.min(total - 1, Long.parseLong(p[1].trim())); }
                    else if (p.length > 1 && !p[1].trim().isEmpty()) { start = Math.max(0, total - Long.parseLong(p[1].trim())); }
                    partial = true;
                }
                if (start > end && total > 0) { out.write(("HTTP/1.1 416 Range Not Satisfiable\r\n" + cors + "Content-Range: bytes */" + total + "\r\nContent-Length: 0\r\nConnection: close\r\n\r\n").getBytes()); return; }
                String type = type0 == null ? "application/octet-stream" : type0;
                long len = Math.max(0, end - start + 1);
                StringBuilder hdr = new StringBuilder();
                hdr.append(partial ? "HTTP/1.1 206 Partial Content\r\n" : "HTTP/1.1 200 OK\r\n");
                hdr.append("Content-Type: ").append(type).append("\r\n").append("Accept-Ranges: bytes\r\n").append("Content-Length: ").append(len).append("\r\n");
                if (partial) hdr.append("Content-Range: bytes ").append(start).append("-").append(end).append("/").append(total).append("\r\n");
                hdr.append(cors).append("Cache-Control: no-store\r\nConnection: close\r\n\r\n");
                out.write(hdr.toString().getBytes());
                if ("HEAD".equals(method)) { out.flush(); return; }
                fin.getChannel().position(fin.getChannel().position() + start);
                byte[] buf = new byte[256 * 1024]; long left = len; int n;
                while (left > 0 && (n = fin.read(buf, 0, (int) Math.min(buf.length, left))) > 0) { out.write(buf, 0, n); left -= n; }
                out.flush();
            } finally { try { if (afd != null) afd.close(); } catch (Exception ignored) { } }
        } catch (Exception ignored) { }
    }

    private void handleAsr(String method, String target, Map<String, String> h, InputStream in, OutputStream out, String cors) throws Exception {
        int code = 200; String body;
        try {
            if (!"POST".equals(method)) throw new Exception("POST only");
            AsrHandler a = asr; if (a == null) throw new Exception("speech AI not available");
            long len = Long.parseLong(h.getOrDefault("content-length", "0"));
            if (len <= 0 || len > 64L * 1024 * 1024 || len % 4 != 0) throw new Exception("bad audio size");
            byte[] b = new byte[(int) len]; int off = 0, n;
            while (off < b.length && (n = in.read(b, off, b.length - off)) > 0) off += n;
            if (off < b.length) throw new Exception("audio cut off");
            float[] pcm = new float[b.length / 4];
            java.nio.ByteBuffer.wrap(b).order(java.nio.ByteOrder.LITTLE_ENDIAN).asFloatBuffer().get(pcm);
            String kind = target.contains("k=accurate") ? "accurate" : "fast";
            body = a.run(kind, pcm);
        } catch (Exception e) {
            code = 500; body = "{\"error\":" + org.json.JSONObject.quote(String.valueOf(e.getMessage())) + "}";
        }
        byte[] bb = body.getBytes(java.nio.charset.StandardCharsets.UTF_8);
        out.write(((code == 200 ? "HTTP/1.1 200 OK\r\n" : "HTTP/1.1 500 Internal Server Error\r\n") + "Content-Type: application/json; charset=utf-8\r\n"
                + "Content-Length: " + bb.length + "\r\n" + cors + "Cache-Control: no-store\r\nConnection: close\r\n\r\n").getBytes());
        out.write(bb); out.flush();
    }

    private static String readLine(InputStream in) throws Exception {
        StringBuilder sb = new StringBuilder(); int c;
        while ((c = in.read()) != -1) { if (c == '\n') break; if (c != '\r') sb.append((char) c); if (sb.length() > 8192) break; }
        return c == -1 && sb.length() == 0 ? null : sb.toString();
    }
}
