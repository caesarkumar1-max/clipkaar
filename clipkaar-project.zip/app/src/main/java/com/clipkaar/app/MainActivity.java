package com.clipkaar.app;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Color;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {

    private static final int PICK_VIDEOS = 1001;
    private static final String APP_URL = "https://appassets.androidplatform.net/assets/index.html";

    private WebView web;
    private ValueCallback<Uri[]> fileCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);

        web = new WebView(this);
        web.setBackgroundColor(Color.BLACK);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        setContentView(web);

        // Serve the editor from a secure https origin so audio worklets, recording and blobs all work.
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                String p0 = request.getUrl().getPath();
                if ("appassets.androidplatform.net".equals(request.getUrl().getHost()) && p0 != null && p0.startsWith("/media/"))
                    return serveMedia(request);
                if ("appassets.androidplatform.net".equals(request.getUrl().getHost()) && p0 != null && p0.startsWith("/thumb/"))
                    return serveThumb(request);
                WebResourceResponse r = loader.shouldInterceptRequest(request.getUrl());
                if (r != null) {
                    // Cross-origin isolation lets the AI models use several CPU cores.
                    Map<String, String> h = new HashMap<>();
                    if (r.getResponseHeaders() != null) h.putAll(r.getResponseHeaders());
                    h.put("Cross-Origin-Opener-Policy", "same-origin");
                    h.put("Cross-Origin-Embedder-Policy", "credentialless");
                    h.put("Cross-Origin-Resource-Policy", "same-origin");
                    String path = request.getUrl().getPath();
                    if (path != null && (path.endsWith(".js") || path.endsWith(".mjs"))) r.setMimeType("text/javascript");
                    if (path != null && path.endsWith(".wasm")) r.setMimeType("application/wasm");
                    r.setResponseHeaders(h);
                }
                return r;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if ("appassets.androidplatform.net".equals(u.getHost())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (ActivityNotFoundException ignored) { }
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                // OPEN_DOCUMENT lets the app keep reading the original file later, so projects don't need a copy
                Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                pick.addCategory(Intent.CATEGORY_OPENABLE);
                pick.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                // accept="video/*,image/*" or "audio/*" from the page
                java.util.ArrayList<String> types = new java.util.ArrayList<>();
                String[] acc = params.getAcceptTypes();
                if (acc != null) for (String a : acc) for (String t : a.split(",")) { t = t.trim(); if (!t.isEmpty()) types.add(t); }
                if (types.isEmpty()) types.add("video/*");
                if (types.size() == 1) pick.setType(types.get(0));
                else { pick.setType("*/*"); pick.putExtra(Intent.EXTRA_MIME_TYPES, types.toArray(new String[0])); }
                pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                String title = types.get(0).startsWith("audio") ? "Choose music" : "Choose videos or photos";
                try {
                    startActivityForResult(Intent.createChooser(pick, title), PICK_VIDEOS);
                } catch (ActivityNotFoundException e) {
                    fileCallback = null;
                    Toast.makeText(MainActivity.this, "No file picker found", Toast.LENGTH_SHORT).show();
                    return false;
                }
                return true;
            }
        });

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);

        web.addJavascriptInterface(new Bridge(), "AndroidBridge");

        if (savedInstanceState != null) web.restoreState(savedInstanceState);
        else web.loadUrl(APP_URL);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        web.saveState(outState);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_VIDEOS || fileCallback == null) return;
        Uri[] result = null;
        if (resultCode == RESULT_OK && data != null) {
            if (data.getClipData() != null) {
                int n = data.getClipData().getItemCount();
                result = new Uri[n];
                for (int i = 0; i < n; i++) result[i] = data.getClipData().getItemAt(i).getUri();
            } else if (data.getData() != null) {
                result = new Uri[]{data.getData()};
            }
        }
        // remember the picked files (name, size, link) so the editor can store links instead of copies
        org.json.JSONArray arr = new org.json.JSONArray();
        if (result != null) for (Uri u : result) {
            try { getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) { }
            try { arr.put(uriJson(u)); } catch (Exception ignored) { }
        }
        lastPicked = arr.toString();
        fileCallback.onReceiveValue(result);
        fileCallback = null;
    }

    private volatile String lastPicked = "[]";
    private static final int PERM_REQ = 2001;

    /* ---------- in-app gallery ---------- */
    private String[] mediaPerms() {
        if (Build.VERSION.SDK_INT >= 34) return new String[]{"android.permission.READ_MEDIA_VIDEO", "android.permission.READ_MEDIA_IMAGES", "android.permission.READ_MEDIA_VISUAL_USER_SELECTED"};
        if (Build.VERSION.SDK_INT >= 33) return new String[]{"android.permission.READ_MEDIA_VIDEO", "android.permission.READ_MEDIA_IMAGES"};
        return new String[]{"android.permission.READ_EXTERNAL_STORAGE"};
    }
    private boolean has(String p) { return checkSelfPermission(p) == android.content.pm.PackageManager.PERMISSION_GRANTED; }
    private String permState() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (has("android.permission.READ_MEDIA_VIDEO") && has("android.permission.READ_MEDIA_IMAGES")) return "granted";
            if (Build.VERSION.SDK_INT >= 34 && has("android.permission.READ_MEDIA_VISUAL_USER_SELECTED")) return "partial";
            return "denied";
        }
        return has("android.permission.READ_EXTERNAL_STORAGE") ? "granted" : "denied";
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code == PERM_REQ) web.evaluateJavascript("window.__permResult&&window.__permResult('" + permState() + "')", null);
    }

    private String listMedia(boolean video, int offset, int limit) {
        org.json.JSONArray arr = new org.json.JSONArray();
        Uri coll = video ? MediaStore.Video.Media.EXTERNAL_CONTENT_URI : MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        java.util.ArrayList<String> cols = new java.util.ArrayList<>(java.util.Arrays.asList(
                MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.SIZE,
                MediaStore.MediaColumns.MIME_TYPE, MediaStore.MediaColumns.DATE_ADDED, MediaStore.MediaColumns.WIDTH, MediaStore.MediaColumns.HEIGHT));
        if (video) cols.add(MediaStore.Video.Media.DURATION);
        String sort = MediaStore.MediaColumns.DATE_ADDED + " DESC";
        try (android.database.Cursor c = getContentResolver().query(coll, cols.toArray(new String[0]), null, null, sort)) {
            if (c == null) return "[]";
            if (offset > 0 && !c.moveToPosition(offset - 1)) return "[]";
            int n = 0;
            while (c.moveToNext() && n < limit) {
                long id = c.getLong(0);
                org.json.JSONObject o = new org.json.JSONObject();
                o.put("uri", android.content.ContentUris.withAppendedId(coll, id).toString());
                o.put("name", c.getString(1) == null ? "" : c.getString(1));
                o.put("size", c.getLong(2)); o.put("type", c.getString(3) == null ? "" : c.getString(3));
                o.put("date", c.getLong(4)); o.put("w", c.getInt(5)); o.put("h", c.getInt(6));
                if (video) o.put("dur", c.getLong(7));
                o.put("ok", true);
                arr.put(o); n++;
            }
        } catch (Exception e) { return "[]"; }
        return arr.toString();
    }

    private WebResourceResponse serveThumb(WebResourceRequest req) {
        Map<String, String> h = new HashMap<>();
        h.put("Cross-Origin-Resource-Policy", "same-origin");
        h.put("Cache-Control", "max-age=86400");
        try {
            Uri u = Uri.parse(req.getUrl().getQueryParameter("u"));
            int s = 256; try { s = Integer.parseInt(req.getUrl().getQueryParameter("s")); } catch (Exception ignored) { }
            android.graphics.Bitmap bm;
            if (Build.VERSION.SDK_INT >= 29) bm = getContentResolver().loadThumbnail(u, new android.util.Size(s, s), null);
            else {
                long id = android.content.ContentUris.parseId(u);
                bm = u.toString().contains("/video/")
                        ? MediaStore.Video.Thumbnails.getThumbnail(getContentResolver(), id, MediaStore.Video.Thumbnails.MINI_KIND, null)
                        : MediaStore.Images.Thumbnails.getThumbnail(getContentResolver(), id, MediaStore.Images.Thumbnails.MINI_KIND, null);
            }
            if (bm == null) throw new Exception("no thumb");
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            bm.compress(android.graphics.Bitmap.CompressFormat.JPEG, 80, bo);
            return new WebResourceResponse("image/jpeg", null, 200, "OK", h, new java.io.ByteArrayInputStream(bo.toByteArray()));
        } catch (Exception e) {
            return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found", h, new java.io.ByteArrayInputStream(new byte[0]));
        }
    }

    private org.json.JSONObject uriJson(Uri u) throws Exception {
        org.json.JSONObject o = new org.json.JSONObject();
        o.put("uri", u.toString());
        String name = null; long size = -1;
        try (android.database.Cursor c = getContentResolver().query(u, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int ni = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME), si = c.getColumnIndex(android.provider.OpenableColumns.SIZE);
                if (ni >= 0) name = c.getString(ni);
                if (si >= 0 && !c.isNull(si)) size = c.getLong(si);
            }
        }
        if (size < 0) try (android.content.res.AssetFileDescriptor fd = getContentResolver().openAssetFileDescriptor(u, "r")) { if (fd != null) size = fd.getLength(); }
        o.put("name", name == null ? "" : name); o.put("size", size);
        String t = getContentResolver().getType(u); o.put("type", t == null ? "" : t);
        o.put("ok", size >= 0);
        return o;
    }

    /** Streams a picked file to the editor, with byte ranges so long videos never load fully into memory. */
    private WebResourceResponse serveMedia(WebResourceRequest req) {
        Map<String, String> h = new HashMap<>();
        h.put("Access-Control-Allow-Origin", "*");
        h.put("Cross-Origin-Resource-Policy", "same-origin");
        h.put("Accept-Ranges", "bytes");
        try {
            Uri u = Uri.parse(req.getUrl().getQueryParameter("u"));
            String type = getContentResolver().getType(u); if (type == null) type = "application/octet-stream";
            android.content.res.AssetFileDescriptor afd = getContentResolver().openAssetFileDescriptor(u, "r");
            long total = afd.getLength();
            FileInputStream in = afd.createInputStream();
            if (total < 0) total = in.getChannel().size();
            long start = 0, end = total - 1; int status = 200; String reason = "OK";
            String range = null;
            for (Map.Entry<String, String> e : req.getRequestHeaders().entrySet()) if ("range".equalsIgnoreCase(e.getKey())) range = e.getValue();
            if (range != null && range.startsWith("bytes=")) {
                String[] p = range.substring(6).split("-", -1);
                if (!p[0].isEmpty()) start = Long.parseLong(p[0].trim());
                if (p.length > 1 && !p[1].trim().isEmpty()) end = Math.min(total - 1, Long.parseLong(p[1].trim()));
                if (p[0].isEmpty() && p.length > 1) { start = Math.max(0, total - Long.parseLong(p[1].trim())); end = total - 1; }
                status = 206; reason = "Partial Content";
                h.put("Content-Range", "bytes " + start + "-" + end + "/" + total);
            }
            in.getChannel().position(in.getChannel().position() + start);
            long len = Math.max(0, end - start + 1);
            h.put("Content-Length", String.valueOf(len));
            final long[] left = {len};
            InputStream limited = new InputStream() {
                @Override public int read() throws java.io.IOException { if (left[0] <= 0) return -1; int b = in.read(); if (b >= 0) left[0]--; return b; }
                @Override public int read(byte[] b, int off, int n) throws java.io.IOException { if (left[0] <= 0) return -1; int r = in.read(b, off, (int) Math.min(n, left[0])); if (r > 0) left[0] -= r; return r; }
                @Override public void close() throws java.io.IOException { in.close(); afd.close(); }
            };
            return new WebResourceResponse(type, null, status, reason, h, limited);
        } catch (Exception e) {
            return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found", h, new java.io.ByteArrayInputStream(new byte[0]));
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        web.evaluateJavascript("(window.__back && window.__back()) ? 'yes' : 'no'", value -> {
            if (value == null || !value.contains("yes")) super.onBackPressed();
        });
    }

    // The editor keeps working (export, captions) when you switch apps, so the WebView is not paused here.

    /** Receives an exported file from the editor in base64 chunks and saves it to the gallery / Downloads. */
    private class Bridge {
        private File tmp;
        private OutputStream out;
        private String name = "clipkaar.mp4";
        private String mime = "video/mp4";

        @JavascriptInterface
        public String lastPicked() { return lastPicked; }

        @JavascriptInterface
        public String mediaPermission() { return permState(); }

        @JavascriptInterface
        public void requestMediaPermission() { runOnUiThread(() -> requestPermissions(mediaPerms(), PERM_REQ)); }

        @JavascriptInterface
        public String listMedia(String kind, int offset, int limit) { return MainActivity.this.listMedia("video".equals(kind), offset, limit); }

        @JavascriptInterface
        public void openAppSettings() {
            runOnUiThread(() -> { try { startActivity(new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()))); } catch (Exception ignored) { } });
        }

        @JavascriptInterface
        public String uriInfo(String uri) {
            try { return uriJson(Uri.parse(uri)).toString(); } catch (Exception e) { return "{\"ok\":false}"; }
        }

        @JavascriptInterface
        public void keepAwake(boolean on) {
            runOnUiThread(() -> {
                if (on) getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                else getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            });
        }

        @JavascriptInterface
        public boolean begin(String fileName, String mimeType) {
            try {
                if (out != null) out.close();
                name = fileName;
                mime = mimeType;
                tmp = new File(getCacheDir(), "export.tmp");
                out = new FileOutputStream(tmp);
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public boolean append(String base64) {
            try {
                out.write(Base64.decode(base64, Base64.DEFAULT));
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public String finish() {
            try {
                out.close();
                out = null;
                String where = saveToStorage();
                tmp.delete();
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Saved: " + where, Toast.LENGTH_LONG).show());
                return where;
            } catch (Exception e) {
                return "ERR:" + e.getMessage();
            }
        }

        private String saveToStorage() throws Exception {
            boolean isVideo = mime.startsWith("video");
            if (Build.VERSION.SDK_INT >= 29) {
                ContentResolver cr = getContentResolver();
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                String folder = (isVideo ? Environment.DIRECTORY_MOVIES : Environment.DIRECTORY_DOWNLOADS) + "/Clipkaar";
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, folder);
                v.put(MediaStore.MediaColumns.IS_PENDING, 1);
                Uri collection = isVideo
                        ? MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                        : MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
                Uri item = cr.insert(collection, v);
                if (item == null) throw new Exception("Could not create file");
                try (InputStream in = new FileInputStream(tmp); OutputStream o = cr.openOutputStream(item)) {
                    copy(in, o);
                }
                v.clear();
                v.put(MediaStore.MediaColumns.IS_PENDING, 0);
                cr.update(item, v, null, null);
                return folder + "/" + name;
            } else {
                // Android 9 and older: app's own folder, no storage permission needed.
                File target = getExternalFilesDir(isVideo ? Environment.DIRECTORY_MOVIES : Environment.DIRECTORY_DOWNLOADS);
                if (target != null && !target.exists()) target.mkdirs();
                File f = new File(target, name);
                try (InputStream in = new FileInputStream(tmp); OutputStream o = new FileOutputStream(f)) {
                    copy(in, o);
                }
                MediaScannerConnection.scanFile(MainActivity.this, new String[]{f.getAbsolutePath()}, new String[]{mime}, null);
                return f.getAbsolutePath();
            }
        }

        private void copy(InputStream in, OutputStream o) throws Exception {
            byte[] buf = new byte[1 << 16];
            int n;
            while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
        }
    }
}
