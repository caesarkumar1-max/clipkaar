package com.clipkaar.app;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Color;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {

    private static final int PICK_VIDEOS = 1001;
    private static final String APP_URL = "https://appassets.androidplatform.net/assets/index.html";

    private WebView web;
    private ValueCallback<Uri[]> fileCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);

        web = new WebView(this);
        web.setBackgroundColor(Color.BLACK);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        setContentView(web);

        // Serve the editor from a secure https origin so audio worklets, recording and blobs all work.
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                WebResourceResponse r = loader.shouldInterceptRequest(request.getUrl());
                if (r != null) {
                    // Cross-origin isolation lets the AI models use several CPU cores.
                    Map<String, String> h = new HashMap<>();
                    if (r.getResponseHeaders() != null) h.putAll(r.getResponseHeaders());
                    h.put("Cross-Origin-Opener-Policy", "same-origin");
                    h.put("Cross-Origin-Embedder-Policy", "credentialless");
                    h.put("Cross-Origin-Resource-Policy", "same-origin");
                    String path = request.getUrl().getPath();
                    if (path != null && (path.endsWith(".js") || path.endsWith(".mjs"))) r.setMimeType("text/javascript");
                    if (path != null && path.endsWith(".wasm")) r.setMimeType("application/wasm");
                    r.setResponseHeaders(h);
                }
                return r;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if ("appassets.androidplatform.net".equals(u.getHost())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (ActivityNotFoundException ignored) { }
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
                pick.addCategory(Intent.CATEGORY_OPENABLE);
                // accept="video/*,image/*" or "audio/*" from the page
                java.util.ArrayList<String> types = new java.util.ArrayList<>();
                String[] acc = params.getAcceptTypes();
                if (acc != null) for (String a : acc) for (String t : a.split(",")) { t = t.trim(); if (!t.isEmpty()) types.add(t); }
                if (types.isEmpty()) types.add("video/*");
                if (types.size() == 1) pick.setType(types.get(0));
                else { pick.setType("*/*"); pick.putExtra(Intent.EXTRA_MIME_TYPES, types.toArray(new String[0])); }
                pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                String title = types.get(0).startsWith("audio") ? "Choose music" : "Choose videos or photos";
                try {
                    startActivityForResult(Intent.createChooser(pick, title), PICK_VIDEOS);
                } catch (ActivityNotFoundException e) {
                    fileCallback = null;
                    Toast.makeText(MainActivity.this, "No file picker found", Toast.LENGTH_SHORT).show();
                    return false;
                }
                return true;
            }
        });

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);

        web.addJavascriptInterface(new Bridge(), "AndroidBridge");

        if (savedInstanceState != null) web.restoreState(savedInstanceState);
        else web.loadUrl(APP_URL);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        web.saveState(outState);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_VIDEOS || fileCallback == null) return;
        Uri[] result = null;
        if (resultCode == RESULT_OK && data != null) {
            if (data.getClipData() != null) {
                int n = data.getClipData().getItemCount();
                result = new Uri[n];
                for (int i = 0; i < n; i++) result[i] = data.getClipData().getItemAt(i).getUri();
            } else if (data.getData() != null) {
                result = new Uri[]{data.getData()};
            }
        }
        fileCallback.onReceiveValue(result);
        fileCallback = null;
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        web.evaluateJavascript("(window.__back && window.__back()) ? 'yes' : 'no'", value -> {
            if (value == null || !value.contains("yes")) super.onBackPressed();
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        web.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
    }

    /** Receives an exported file from the editor in base64 chunks and saves it to the gallery / Downloads. */
    private class Bridge {
        private File tmp;
        private OutputStream out;
        private String name = "clipkaar.mp4";
        private String mime = "video/mp4";

        @JavascriptInterface
        public boolean begin(String fileName, String mimeType) {
            try {
                if (out != null) out.close();
                name = fileName;
                mime = mimeType;
                tmp = new File(getCacheDir(), "export.tmp");
                out = new FileOutputStream(tmp);
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public boolean append(String base64) {
            try {
                out.write(Base64.decode(base64, Base64.DEFAULT));
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public String finish() {
            try {
                out.close();
                out = null;
                String where = saveToStorage();
                tmp.delete();
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Saved: " + where, Toast.LENGTH_LONG).show());
                return where;
            } catch (Exception e) {
                return "ERR:" + e.getMessage();
            }
        }

        private String saveToStorage() throws Exception {
            boolean isVideo = mime.startsWith("video");
            if (Build.VERSION.SDK_INT >= 29) {
                ContentResolver cr = getContentResolver();
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                String folder = (isVideo ? Environment.DIRECTORY_MOVIES : Environment.DIRECTORY_DOWNLOADS) + "/Clipkaar";
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, folder);
                v.put(MediaStore.MediaColumns.IS_PENDING, 1);
                Uri collection = isVideo
                        ? MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                        : MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
                Uri item = cr.insert(collection, v);
                if (item == null) throw new Exception("Could not create file");
                try (InputStream in = new FileInputStream(tmp); OutputStream o = cr.openOutputStream(item)) {
                    copy(in, o);
                }
                v.clear();
                v.put(MediaStore.MediaColumns.IS_PENDING, 0);
                cr.update(item, v, null, null);
                return folder + "/" + name;
            } else {
                // Android 9 and older: app's own folder, no storage permission needed.
                File target = getExternalFilesDir(isVideo ? Environment.DIRECTORY_MOVIES : Environment.DIRECTORY_DOWNLOADS);
                if (target != null && !target.exists()) target.mkdirs();
                File f = new File(target, name);
                try (InputStream in = new FileInputStream(tmp); OutputStream o = new FileOutputStream(f)) {
                    copy(in, o);
                }
                MediaScannerConnection.scanFile(MainActivity.this, new String[]{f.getAbsolutePath()}, new String[]{mime}, null);
                return f.getAbsolutePath();
            }
        }

        private void copy(InputStream in, OutputStream o) throws Exception {
            byte[] buf = new byte[1 << 16];
            int n;
            while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
        }
    }
}
