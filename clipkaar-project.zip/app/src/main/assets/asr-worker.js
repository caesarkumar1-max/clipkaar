// English speech-to-text for Clipkaar captions, with a timestamp for every word.
// Runs Whisper base.en (bundled in the app) off the main thread.
import { pipeline, env } from './lib/transformers.min.js';

env.allowLocalModels = true;
env.localModelPath = '/assets/models/';
env.allowRemoteModels = true;           // only used if the bundled model is missing
env.useBrowserCache = true;
env.backends.onnx.wasm.wasmPaths = '/assets/lib/';
env.backends.onnx.wasm.numThreads = self.crossOriginIsolated
  ? Math.max(1, Math.min(4, (navigator.hardwareConcurrency || 4) - 1))
  : 1;

const MODEL = 'onnx-community/whisper-base.en_timestamped';
let asr = null;
let loading = null;
let wordsOK = true;

function getAsr() {
  if (asr) return Promise.resolve(asr);
  if (!loading) {
    const seen = {};
    loading = pipeline('automatic-speech-recognition', MODEL, {
      dtype: { encoder_model: 'q8', decoder_model_merged: 'q8' },
      device: 'wasm',
      progress_callback: (p) => {
        if (p.status === 'progress' && p.total) {
          seen[p.file] = [p.loaded, p.total];
          let a = 0, b = 0;
          for (const k in seen) { a += seen[k][0]; b += seen[k][1]; }
          self.postMessage({ type: 'progress', text: `loading AI ${Math.round((a / b) * 100)}%` });
        } else if (p.status === 'ready') {
          self.postMessage({ type: 'progress', text: '' });
        }
      },
    }).then((p) => (asr = p)).catch((e) => { loading = null; throw e; });
  }
  return loading;
}

self.onmessage = async (e) => {
  const { id, audio } = e.data;
  try {
    const run = await getAsr();
    // Each piece sent here is 30 s or less, so no chunking is needed (faster).
    let out;
    if (wordsOK) {
      try {
        out = await run(audio, { return_timestamps: 'word' });
      } catch (err) {
        wordsOK = false;               // model without word timing: fall back to phrases
      }
    }
    if (!out) out = await run(audio, { return_timestamps: true });
    let chunks = out.chunks && out.chunks.length ? out.chunks : [];
    if (!wordsOK) {
      // spread phrase timing across its words
      const words = [];
      for (const c of chunks) {
        const ws = String(c.text || '').trim().split(/\s+/).filter(Boolean);
        const a = c.timestamp[0] ?? 0, b = c.timestamp[1] ?? a + ws.length * 0.35, d = (b - a) / Math.max(1, ws.length);
        ws.forEach((w, i) => words.push({ text: ' ' + w, timestamp: [a + i * d, a + (i + 1) * d] }));
      }
      chunks = words;
    }
    self.postMessage({ type: 'done', id, chunks });
  } catch (err) {
    self.postMessage({ type: 'error', id, message: String((err && err.message) || err) });
  }
};
