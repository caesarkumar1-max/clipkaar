// English speech-to-text for Clipkaar captions, with a timestamp for every word.
// Fast = Whisper tiny.en (about 3x quicker), Accurate = Whisper base.en. Both are bundled in the app.
import { pipeline, env } from './lib/transformers.min.js';

env.allowLocalModels = true;
env.localModelPath = '/assets/models/';
env.allowRemoteModels = true;           // only used if a bundled model is missing
env.useBrowserCache = true;
env.backends.onnx.wasm.wasmPaths = '/assets/lib/';
const THREADS = self.crossOriginIsolated
  ? Math.max(1, Math.min(6, (navigator.hardwareConcurrency || 4) - 1))
  : 1;
env.backends.onnx.wasm.numThreads = THREADS;

const MODELS = {
  fast: 'onnx-community/whisper-tiny.en_timestamped',
  accurate: 'onnx-community/whisper-base.en_timestamped',
};
const pipes = {};
const wordsOK = {};

function getAsr(kind) {
  const id = MODELS[kind] || MODELS.fast;
  if (!pipes[id]) {
    const seen = {};
    pipes[id] = pipeline('automatic-speech-recognition', id, {
      dtype: { encoder_model: 'q8', decoder_model_merged: 'q8' },
      device: 'wasm',
      progress_callback: (p) => {
        if (p.status === 'progress' && p.total) {
          seen[p.file] = [p.loaded, p.total];
          let a = 0, b = 0;
          for (const k in seen) { a += seen[k][0]; b += seen[k][1]; }
          self.postMessage({ type: 'progress', text: `loading AI ${Math.round((a / b) * 100)}%` });
        } else if (p.status === 'ready') {
          self.postMessage({ type: 'progress', text: '' });
          self.postMessage({ type: 'info', text: `${THREADS} CPU core${THREADS > 1 ? 's' : ''}` });
        }
      },
    }).catch((e) => { delete pipes[id]; throw e; });
    wordsOK[id] = true;
  }
  return pipes[id].then((p) => [p, id]);
}

self.onmessage = async (e) => {
  const { id, audio, model } = e.data;
  try {
    const [run, mid] = await getAsr(model);
    // Each piece sent here is 30 s or less, so no chunking is needed (faster).
    let out;
    if (wordsOK[mid]) {
      try { out = await run(audio, { return_timestamps: 'word' }); }
      catch (err) { wordsOK[mid] = false; }
    }
    if (!out) out = await run(audio, { return_timestamps: true });
    let chunks = out.chunks && out.chunks.length ? out.chunks : [];
    if (!wordsOK[mid]) {
      const words = [];
      for (const c of chunks) {
        const ws = String(c.text || '').trim().split(/\s+/).filter(Boolean);
        const a = c.timestamp[0] ?? 0, b = c.timestamp[1] ?? a + ws.length * 0.35, d = (b - a) / Math.max(1, ws.length);
        ws.forEach((w, i) => words.push({ text: ' ' + w, timestamp: [a + i * d, a + (i + 1) * d] }));
      }
      chunks = words;
    }
    self.postMessage({ type: 'done', id, chunks });
  } catch (err) {
    self.postMessage({ type: 'error', id, message: String((err && err.message) || err) });
  }
};
