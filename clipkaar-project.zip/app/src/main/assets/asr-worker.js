// Speech-to-text for Clipkaar captions. Runs Whisper (bundled in the app) off the main thread.
import { pipeline, env } from './lib/transformers.min.js';

env.allowLocalModels = true;
env.localModelPath = '/assets/models/';
env.allowRemoteModels = true;           // only used if the bundled model is missing
env.useBrowserCache = true;
env.backends.onnx.wasm.wasmPaths = '/assets/lib/';
env.backends.onnx.wasm.numThreads = self.crossOriginIsolated
  ? Math.max(1, Math.min(4, (navigator.hardwareConcurrency || 4) - 1))
  : 1;

const MODEL = 'Xenova/whisper-base';
let asr = null;
let loading = null;

function getAsr() {
  if (asr) return Promise.resolve(asr);
  if (!loading) {
    const seen = {};
    loading = pipeline('automatic-speech-recognition', MODEL, {
      dtype: { encoder_model: 'q8', decoder_model_merged: 'q8' },
      device: 'wasm',
      progress_callback: (p) => {
        if (p.status === 'progress' && p.total) {
          seen[p.file] = [p.loaded, p.total];
          let a = 0, b = 0;
          for (const k in seen) { a += seen[k][0]; b += seen[k][1]; }
          self.postMessage({ type: 'progress', text: `Loading AI model… ${Math.round((a / b) * 100)}%` });
        } else if (p.status === 'ready') {
          self.postMessage({ type: 'progress', text: 'AI model ready. Listening…' });
        }
      },
    }).then((p) => (asr = p));
  }
  return loading;
}

self.onmessage = async (e) => {
  const { id, audio, language } = e.data;
  try {
    const run = await getAsr();
    const opts = {
      task: 'transcribe',
      return_timestamps: true,
      chunk_length_s: 30,
      stride_length_s: 5,
    };
    if (language && language !== 'auto') opts.language = language;
    const out = await run(audio, opts);
    const chunks = out.chunks && out.chunks.length
      ? out.chunks
      : [{ text: out.text || '', timestamp: [0, audio.length / 16000] }];
    self.postMessage({ type: 'done', id, chunks });
  } catch (err) {
    self.postMessage({ type: 'error', id, message: String((err && err.message) || err) });
  }
};
