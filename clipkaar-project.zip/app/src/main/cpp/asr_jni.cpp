// JNI bridge: Java float[] (16 kHz mono) -> whisper.cpp -> JSON list of words with times in seconds.
#include <jni.h>
#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstdio>
#include <string>
#include <vector>
#include "whisper.h"
#ifdef __ANDROID__
#include <android/log.h>
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, "ClipkaarASR", __VA_ARGS__)
#else
#define LOGW(...) fprintf(stderr, __VA_ARGS__)
#endif

static std::atomic<bool> g_abort(false);

static void quiet_log(enum ggml_log_level level, const char * text, void *) {
    if (level >= GGML_LOG_LEVEL_WARN) LOGW("%s", text);
}

static void json_str(std::string & o, const std::string & s) {
    o += '"';
    for (unsigned char c : s) {
        switch (c) {
            case '"': o += "\\\""; break;
            case '\\': o += "\\\\"; break;
            case '\n': o += "\\n"; break;
            case '\r': o += "\\r"; break;
            case '\t': o += "\\t"; break;
            default:
                if (c < 0x20) { char b[8]; snprintf(b, sizeof b, "\\u%04x", c); o += b; }
                else o += (char) c;
        }
    }
    o += '"';
}

struct Word { std::string text; double s, e; };

extern "C" JNIEXPORT jlong JNICALL
Java_com_clipkaar_app_Asr_nInit(JNIEnv * env, jclass, jstring jpath, jint kind) {
    whisper_log_set(quiet_log, nullptr);
    const char * path = env->GetStringUTFChars(jpath, nullptr);
    whisper_context_params cp = whisper_context_default_params();
    cp.use_gpu = false;
    cp.flash_attn = false;                 // needed for the word-timing (DTW) mode below
    cp.dtw_token_timestamps = true;        // accurate word timing from the model's attention
    cp.dtw_aheads_preset = kind == 1 ? WHISPER_AHEADS_BASE_EN : WHISPER_AHEADS_TINY_EN;
    whisper_context * ctx = whisper_init_from_file_with_params(path, cp);
    if (!ctx) {                            // try again without DTW, plain token timing
        cp.dtw_token_timestamps = false; cp.dtw_aheads_preset = WHISPER_AHEADS_NONE;
        ctx = whisper_init_from_file_with_params(path, cp);
    }
    env->ReleaseStringUTFChars(jpath, path);
    return (jlong) (intptr_t) ctx;
}

extern "C" JNIEXPORT void JNICALL
Java_com_clipkaar_app_Asr_nFree(JNIEnv *, jclass, jlong h) {
    if (h) whisper_free((whisper_context *) (intptr_t) h);
}

extern "C" JNIEXPORT void JNICALL
Java_com_clipkaar_app_Asr_nAbort(JNIEnv *, jclass, jboolean on) { g_abort = on; }

static bool abort_cb(void *) { return g_abort.load(); }

// Returns UTF-8 bytes of {"chunks":[{"text":" word","timestamp":[s,e]},...]} or null on failure.
extern "C" JNIEXPORT jbyteArray JNICALL
Java_com_clipkaar_app_Asr_nRun(JNIEnv * env, jclass, jlong h, jfloatArray jpcm, jint threads) {
    whisper_context * ctx = (whisper_context *) (intptr_t) h;
    if (!ctx || !jpcm) return nullptr;
    const jsize n = env->GetArrayLength(jpcm);
    std::vector<float> pcm(n);
    env->GetFloatArrayRegion(jpcm, 0, n, pcm.data());

    whisper_full_params p = whisper_full_default_params(WHISPER_SAMPLING_GREEDY);
    p.n_threads = threads > 0 ? threads : 4;
    p.language = "en";
    p.translate = false;
    p.no_context = true;
    p.single_segment = false;
    p.print_progress = false; p.print_realtime = false; p.print_timestamps = false; p.print_special = false;
    p.token_timestamps = true;
    p.suppress_blank = true;
    p.suppress_nst = true;                 // no [Music], (laughs) etc.
    p.greedy.best_of = 1;
    p.abort_callback = abort_cb; p.abort_callback_user_data = nullptr;

    g_abort = false;
    if (whisper_full(ctx, p, pcm.data(), (int) pcm.size()) != 0) return nullptr;

    const bool dtw = true;
    const whisper_token eot = whisper_token_eot(ctx);
    std::vector<Word> words;
    const int ns = whisper_full_n_segments(ctx);
    for (int si = 0; si < ns; si++) {
        const int nt = whisper_full_n_tokens(ctx, si);
        for (int ti = 0; ti < nt; ti++) {
            const whisper_token_data td = whisper_full_get_token_data(ctx, si, ti);
            if (td.id >= eot) continue;    // special and timestamp tokens
            const char * tx = whisper_full_get_token_text(ctx, si, ti);
            if (!tx || !*tx) continue;
            std::string t(tx);
            double t0 = td.t0 / 100.0, t1 = td.t1 / 100.0;
            if (dtw && td.t_dtw >= 0) { double d = td.t_dtw / 100.0; t0 = d; if (t1 < d) t1 = d + 0.1; }
            const bool newWord = words.empty() || t[0] == ' ';
            if (newWord) words.push_back({t, t0, t1});
            else { words.back().text += t; if (t1 > words.back().e) words.back().e = t1; }
        }
    }
    // a word ends when the next one starts (keeps captions from flickering), but never after its own end + 0.6 s
    for (size_t i = 0; i + 1 < words.size(); i++) {
        double nx = words[i + 1].s;
        if (nx > words[i].s) words[i].e = std::min(nx, std::max(words[i].e, words[i].s + 0.15) + 0.6);
        if (words[i].e <= words[i].s) words[i].e = words[i].s + 0.2;
    }
    if (!words.empty() && words.back().e <= words.back().s) words.back().e = words.back().s + 0.3;

    std::string o = "{\"chunks\":[";
    char num[64];
    for (size_t i = 0; i < words.size(); i++) {
        if (i) o += ',';
        o += "{\"text\":"; json_str(o, words[i].text);
        snprintf(num, sizeof num, ",\"timestamp\":[%.2f,%.2f]}", words[i].s, words[i].e);
        o += num;
    }
    o += "]}";
    jbyteArray out = env->NewByteArray((jsize) o.size());
    env->SetByteArrayRegion(out, 0, (jsize) o.size(), (const jbyte *) o.data());
    return out;
}
